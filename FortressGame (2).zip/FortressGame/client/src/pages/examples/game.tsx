import Game from '../game';

export default function GameExample() {
  return <Game />;
}
